package com.digitalinnovationone.springbootconfig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootconfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootconfigApplication.class, args);
	}

}
